<!DOCTYPE html>
<html>
<head>
    <title>Folarium </title>
</head>
<body>
  
<div class="container">
    <?php echo $__env->yieldContent('content'); ?>
</div>
   
</body>
</html><?php /**PATH C:\Users\arlex\Folarium-app\resources\views/users/layout.blade.php ENDPATH**/ ?>