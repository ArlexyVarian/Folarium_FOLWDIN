<!DOCTYPE html>
<html>
<head>
    <title>Folarium </title>
</head>
<body>
  
<div class="container">
    @yield('content')
</div>
   
</body>
</html>